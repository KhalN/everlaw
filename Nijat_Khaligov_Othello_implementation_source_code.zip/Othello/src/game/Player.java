package game;

//Notes regarding this:
/*
 * this class could be created as abstract and 
 * we can create different implementations of this
 * class by extending it. E.g we can create 
 * artificial smart player which makes moves by itself. as laying against machine
 * */

public class Player 
{
	private int disk;
	private String name;
	
	public Player( int disk, String name ) 
	{
		this.disk = disk;
		this.name = name;
	}
	
	public int getDisk() 
	{
		return disk;
	}
	
	public String getName() {
		return name;
	}
}
