package game;

import java.util.Arrays;

public class Board 
{
	int [][] board;
	final private static int SIZE 	=   8;
	final private static int EMPTY 	=  -1;
	final private static int TIE 	=  -1;
	
	int numberOfAvailableCells;
	int numberOfBlackDisks;
	int numberOfWhiteDisks;
	int blackDisk;
	int whiteDisk;
	
	public Board( Player black, Player white ) 
	{
		numberOfBlackDisks = 2;
		numberOfWhiteDisks = 2;
		numberOfAvailableCells = SIZE * SIZE - 4;
		int middle = SIZE/2;
		
		board = new int[SIZE][SIZE];
		for(int i = 0; i < board.length; i++ ) {
			Arrays.fill(board[i], EMPTY );
		}	
		
		blackDisk = black.getDisk();
		whiteDisk = white.getDisk();
		
		board[middle-1][middle] 	= blackDisk;
		board[middle][middle-1] 	= blackDisk;
		board[middle-1][middle-1] 	= whiteDisk;
		board[middle][middle] 		= whiteDisk;
	}
	
	public boolean isBoardFull() 
	{
		return numberOfAvailableCells == 0 ? true : false;
	}
	
	public boolean isCellEmpty(int x, int y) 
	{
		return board[x][y] == EMPTY;
	}
	
	public boolean isCellExists(int x, int y) {
		if( x >= 0 && y >= 0 && x < SIZE && y < SIZE )
			return true;
		return false;
	}
	
	//TODO create to check if there is any valid move exists
	public boolean isValidMoveLeft( Player player ) 
	{
		for(int x = 0; x < board.length; x++ ) 
		{
			for(int y = 0; y < board.length; y++ ) 
			{
				if( !isCellEmpty(x, y) )
					continue;
				else if( isDiagTopLeftValid( player, x, y )
						|| isDiagBottomLeftValid( player, x, y )
						|| isDiagTopRightValid( player, x, y )
						|| isDiagBottomRightValid( player, x, y )
						|| isHorizontalLeftValid( player, x, y )
						|| isHorizontalRightValid( player, x, y ) 
						|| isVerticalTopValid( player, x, y ) 
						|| isVerticalBottomValid( player, x, y ) ) {
					return true;
				}
			}
		}
		return false;
	}
	
	/*
	 * if move is valid flip the disks and return true, else return false
	 * 
	 * Player player - curr player
	 * int x, y - coordinates
	 * */
	public boolean makeMove( Player player, int x, int y ) 
	{
		if( !isCellEmpty(x, y) )
			return false;
			
		boolean diagTopLeft = isDiagTopLeftValid( player, x, y );
		boolean diagBottomLeft = isDiagBottomLeftValid( player, x, y );
		boolean diagTopRight = isDiagTopRightValid( player, x, y );
		boolean diagBottomRight = isDiagBottomRightValid( player, x, y );
		
		boolean horizLeft = isHorizontalLeftValid( player, x, y );
		boolean horizRight = isHorizontalRightValid( player, x, y );
		
		boolean verticalTop = isVerticalTopValid( player, x, y );
		boolean verticalBottom = isVerticalBottomValid( player, x, y );
		
		/* start flippings disks if curr move outflanks opposite disk*/
		if( diagTopLeft )
			flipDiagTopLeft( player, x, y );
		if( diagBottomLeft )
			flipDiagBottomLeft( player, x, y );
		if( diagTopRight )
			flipDiagTopRight( player, x, y );
		if( diagBottomRight )
			flipDiagBottomRight( player, x, y );
		
		if( horizLeft )
			flipHorizLeft( player, x, y );
		if( horizRight )
			flipHorizRight( player, x, y );
		
		if( verticalTop )
			flipVerticalTop( player, x, y );
		if( verticalBottom )
			flipVerticalBottom( player, x, y );
		
		boolean isValid = diagTopLeft || diagBottomLeft || diagTopRight || diagBottomRight
				|| horizLeft || horizRight || verticalTop || verticalBottom;
		
		if( isValid ) {
			board[x][y] = player.getDisk();
			numberOfAvailableCells--;
			
			if( player.getDisk() == blackDisk )
				numberOfBlackDisks++;
			else
				numberOfWhiteDisks++;
		}
		
		return isValid;
	}

	/*
	 * display board
	 * */
	public void displayBoard() 
	{
		System.out.print( " ");
		for(int i = 0; i < board.length; i++ ) 
		{
			System.out.print( "   " + i);
		}
		System.out.println();
		
		for(int i = 0; i < board.length; i++ ) 
		{
			System.out.print( i );
			System.out.print( " | " );
			for(int j = 0; j < board[0].length; j++ ) 
			{
				System.out.print( getPrettyOutput( board[i][j] ) + " | ");
			}
			System.out.println();
		}
	}
	
	private String getPrettyOutput(int val) 
	{
		if( val == EMPTY )
			return " ";
		else if( val == blackDisk )
			return "B";
		else
			return "W";
	}
	
	//TODO - display winer message
	public int getWinner() 
	{
		// TODO Auto-generated method stub
		if( numberOfBlackDisks > numberOfWhiteDisks )
			return blackDisk;
		else if( numberOfBlackDisks < numberOfWhiteDisks ) {
			return whiteDisk;
		}else
			return TIE;
	}
	
	/***********************vertical****************************************/
	private boolean isVerticalTopValid(Player player, int x, int y) 
	{
		//out of board values
		if( !isCellExists(x,y) )
			return false;
		
		//is this cell available
		if( !isCellEmpty(x, y) )
			return false;
		
		//if same not valid or empty
		if( !isCellExists(x-1,y) || isCellEmpty(x-1, y) || board[x-1][y] == player.getDisk() )
			return false;
		
		//then at least one opposite player's disk there keep looking
		while( isCellExists(x-1,y) && !isCellEmpty(x-1, y) && board[x-1][y] != player.getDisk() ) {
			x = x - 1;
		}
		//when out of this loop either it's empty or current player's disk
		//if it was consequent opposite player's disks then current player disk then it's fine situation to outflank
		if( isCellExists(x-1,y) && !isCellEmpty(x-1, y) && board[x-1][y] == player.getDisk() )
			return true;
		
		return false;
	}
	
	private boolean isVerticalBottomValid(Player player, int x, int y) 
	{
		//out of board values
		if( !isCellExists(x,y) )
			return false;
		
		//is this cell available
		if( !isCellEmpty(x, y) )
			return false;
		
		//if same not valid or empty
		if( !isCellExists(x+1,y) || isCellEmpty(x+1, y) || board[x+1][y] == player.getDisk() )
			return false;
		
		//then if opposite player's disk there keep looking
		while( isCellExists(x+1,y) && !isCellEmpty(x+1, y) && board[x+1][y] != player.getDisk() ) {
			x = x + 1;
		}
		//when out of this loop either it's empty or current player's disk
		//if it was consequent opposite player's disks then current player disk then it's fine situation to outflank
		if( isCellExists(x+1,y) && !isCellEmpty(x+1, y) && board[x+1][y] == player.getDisk() )
			return true;
		
		return false;
	}
	
	/***********************horizontal****************************************/
	private boolean isHorizontalLeftValid(Player player, int x, int y) 
	{
		//out of board values
		if( !isCellExists(x,y) )
			return false;
		
		//is this cell available
		if( !isCellEmpty(x, y) )
			return false;
		
		//if same not valid or empty
		if( !isCellExists(x,y-1) ||isCellEmpty(x, y-1) || board[x][y-1] == player.getDisk() )
			return false;
		
		//then if opposite player's disk there keep looking
		while( isCellExists(x,y-1) && !isCellEmpty(x, y-1) && board[x][y-1] != player.getDisk() ) {
			y--;
		}
		//when out of this loop either it's empty or current player's disk
		//if it was consequent opposite player's disks then current player disk then it's fine situation to outflank
		if( isCellExists(x,y-1) && !isCellEmpty(x, y-1) && board[x][y-1] == player.getDisk() )
			return true;
		
		return false;
	}
	
	private boolean isHorizontalRightValid(Player player, int x, int y) 
	{
		//out of board values
		if( !isCellExists(x,y) )
			return false;
		
		//is this cell available
		if( !isCellEmpty(x, y) )
			return false;
		
		//if same not valid or empty
		if( !isCellExists(x,y+1) || isCellEmpty(x, y+1) || board[x][y+1] == player.getDisk() )
			return false;
		
		//then if opposite player's disk there keep looking
		while( isCellExists(x,y+1) && !isCellEmpty(x, y+1) && board[x][y+1] != player.getDisk() ) {
			y++;
		}
		//when out of this loop either it's empty or current player's disk
		//if it was consequent opposite player's disks then current player disk then it's fine situation to outflank
		if( isCellExists(x,y+1) && !isCellEmpty(x, y+1) && board[x][y+1] == player.getDisk() )
			return true;
		
		return false;
	}
	/***********************diogonal****************************************/
	
	private boolean isDiagTopLeftValid(Player player, int x, int y) 
	{
		//out of board values
		if( !isCellExists(x,y) )
			return false;
		
		//is this cell available
		if( !isCellEmpty(x, y) )
			return false;
		
		//if same not valid or empty
		if( !isCellExists(x-1,y-1) || isCellEmpty(x-1, y-1) || board[x-1][y-1] == player.getDisk() )
			return false;
		
		//then if opposite player's disk there keep looking
		while( isCellExists(x-1,y-1) && !isCellEmpty(x-1, y-1) && board[x-1][y-1] != player.getDisk() ) {
			x = x - 1;
			y = y - 1;
		}
		//when out of this loop either it's empty or current player's disk
		//if it was consequent opposite player's disks then current player disk then it's fine situation to outflank
		if( isCellExists(x-1,y-1) && !isCellEmpty(x-1, y-1) && board[x-1][y-1] == player.getDisk() )
			return true;
		
		return false;
	}
	
	private boolean isDiagTopRightValid(Player player, int x, int y) 
	{
		//out of board values
		if( !isCellExists(x,y) )
			return false;
		
		//is this cell available
		if( !isCellEmpty(x, y) )
			return false;
		
		//if same not valid or empty
		if( !isCellExists(x-1,y+1) || isCellEmpty(x-1, y+1) || board[x-1][y+1] == player.getDisk() )
			return false;
		
		//then if opposite player's disk there keep looking
		while( isCellExists(x-1,y+1) && !isCellEmpty(x-1, y+1) && board[x-1][y+1] != player.getDisk() ) {
			x = x - 1;
			y = y + 1;
		}
		//when out of this loop either it's empty or current player's disk
		//if it was consequent opposite player's disks then current player disk then it's fine situation to outflank
		if( isCellExists(x-1,y+1) && !isCellEmpty(x-1, y+1) && board[x-1][y+1] == player.getDisk() )
			return true;
		
		return false;
	}
	
	private boolean isDiagBottomLeftValid(Player player, int x, int y) 
	{
		//out of board values
		if( !isCellExists(x,y) )
			return false;
		
		//is this cell available
		if( !isCellEmpty(x, y) )
			return false;
		
		//if same not valid or empty
		if( !isCellExists(x+1,y-1) || isCellEmpty(x+1, y-1) || board[x+1][y-1] == player.getDisk() )
			return false;
		
		//then if opposite player's disk there keep looking
		while( isCellExists(x+1,y-1) && !isCellEmpty(x+1, y-1) && board[x+1][y-1] != player.getDisk() ) {
			x = x + 1;
			y = y - 1;
		}
		//when out of this loop either it's empty or current player's disk
		//if it was consequent opposite player's disks then current player disk then it's fine situation to outflank
		if( isCellExists(x+1,y-1) && !isCellEmpty(x+1, y-1) && board[x+1][y-1] == player.getDisk() )
			return true;
		
		return false;
	}
	
	private boolean isDiagBottomRightValid(Player player, int x, int y) 
	{
		//out of board values
		if( !isCellExists(x,y) )
			return false;
		
		//is this cell available
		if( !isCellEmpty(x, y) )
			return false;
		
		//if same not valid or empty
		if( !isCellExists(x+1,y+1) || isCellEmpty(x+1, y+1) || board[x+1][y+1] == player.getDisk() )
			return false;
		
		//then if opposite player's disk there keep looking
		while( isCellExists(x+1,y+1) && !isCellEmpty(x+1, y+1) && board[x+1][y+1] != player.getDisk() ) {
			x = x + 1;
			y = y + 1;
		}
		//when out of this loop either it's empty or current player's disk
		//if it was consequent opposite player's disks then current player disk then it's fine situation to outflank
		if( isCellExists(x+1,y+1) && !isCellEmpty(x+1, y+1) && board[x+1][y+1] == player.getDisk() )
			return true;
		
		return false;
	}
	
	/**********validations END HERE***************/
	
	//update number of present disks after flips
	private void updateDiskCounts( int diskColor ) 
	{
		if( diskColor == blackDisk ) {
			numberOfBlackDisks++;
			numberOfWhiteDisks--;
		}else {
			numberOfBlackDisks--;
			numberOfWhiteDisks++;
		}
	}
	
	/** Flipping methods of disks in different directions **/
	private void flipVerticalBottom(Player player, int x, int y) 
	{
		// TODO Auto-generated method stub
		x = x + 1;
		
		//while it's opposite player's then disk flip it
		while( isCellExists(x,y) && !isCellEmpty(x,y) && board[x][y] != player.getDisk() ) 
		{
			board[x][y] = player.getDisk();
			updateDiskCounts( player.getDisk() );
			x = x + 1;
		}	
	}

	private void flipVerticalTop(Player player, int x, int y) {
		// TODO Auto-generated method stub
		x = x - 1;
		
		//while it's opposite player's disk then flip it
		while( isCellExists(x,y) &&  !isCellEmpty(x,y) && board[x][y] != player.getDisk() ) 
		{
			board[x][y] = player.getDisk();
			updateDiskCounts( player.getDisk() );
			x = x - 1;
		}
	}

	private void flipHorizLeft(Player player, int x, int y) {
		// TODO Auto-generated method stub
		y = y - 1;
		
		//while it's opposite player's disk then flip it
		while( isCellExists(x,y) &&  !isCellEmpty(x,y) && board[x][y] != player.getDisk() ) 
		{
			board[x][y] = player.getDisk();
			updateDiskCounts( player.getDisk() );
			y = y - 1;
		}
	}

	private void flipHorizRight(Player player, int x, int y) {
		// TODO Auto-generated method stub
		y = y + 1;
		
		//while it's opposite player's disk then flip it
		while( isCellExists(x,y) &&  !isCellEmpty(x,y) && board[x][y] != player.getDisk() ) 
		{
			board[x][y] = player.getDisk();
			updateDiskCounts( player.getDisk() );
			y++;
		}
	}

	private void flipDiagBottomRight(Player player, int x, int y) {
		// TODO Auto-generated method stub
		x++;
		y++;
		
		//while it's opposite player's disk then flip it
		while( isCellExists(x,y) &&  !isCellEmpty(x,y) && board[x][y] != player.getDisk() ) 
		{
			board[x][y] = player.getDisk();
			updateDiskCounts( player.getDisk() );
			x++;
			y++;
		}
	}

	private void flipDiagTopRight(Player player, int x, int y) {
		// TODO Auto-generated method stub
		x--;
		y++;
		
		//while it's opposite player's disk then flip it
		while( isCellExists(x,y) &&  !isCellEmpty(x,y) && board[x][y] != player.getDisk() ) 
		{
			board[x][y] = player.getDisk();
			updateDiskCounts( player.getDisk() );
			x--;
			y++;
		}
	}

	private void flipDiagBottomLeft(Player player, int x, int y) {
		// TODO Auto-generated method stub
		x++;
		y--;
		
		//while it's opposite player's disk then flip it
		while( isCellExists(x,y) &&  !isCellEmpty(x,y) && board[x][y] != player.getDisk() ) 
		{
			board[x][y] = player.getDisk();
			updateDiskCounts( player.getDisk() );
			x++;
			y--;
		}
	}

	private void flipDiagTopLeft(Player player, int x, int y) {
		// TODO Auto-generated method stub
		x--;
		y--;
		
		//while it's opposite player's disk then flip it
		while( isCellExists(x,y) &&  !isCellEmpty(x,y) && board[x][y] != player.getDisk() ) 
		{
			board[x][y] = player.getDisk();
			updateDiskCounts( player.getDisk() );
			x--;
			y--;
		}
	}
}