To DO:
1. Code refactoring (in ceratin places chckings can be refactored to have less code)
2. isValidMoveLeft method in Board can be optimized.
3. Unit testing can be added to check al the edge cases

HOW TO PLAY GAME;

On each users turn you enter x and y coordinates of the cell. cell numbered from 0 to n. 
after entering x, press enter to input the y value, then press enter again.