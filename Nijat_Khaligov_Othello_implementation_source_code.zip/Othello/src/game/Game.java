package game;

import java.util.Scanner;

public class Game 
{
	public static final int BLACK_DISK = 1;
	public static final int WHITE_DISK = 2;
	
	private Player currPlayer;
	private Player blackPlayer, whitePlayer;
	private Board board;
	private boolean gameDone = false;
	
	public Game() 
	{
		blackPlayer = new Player( BLACK_DISK, "Black" );
		whitePlayer = new Player( WHITE_DISK , "White");
		currPlayer = blackPlayer;
		board = new Board( blackPlayer, whitePlayer );
	}
	
	public void startGame() 
	{
		Scanner scanner = new Scanner(System.in);
		
		while(  true ) 
		{
			System.out.println( currPlayer.getName() + "'s turn!" );
			board.displayBoard();
			int x = scanner.nextInt();
			int y = scanner.nextInt();
			
			//TODO: show board and show the winner
			if( board.isBoardFull() ) {
				//TODO show the winner
				displayGameResults();
				break;
			}
			
			if( board.isCellExists(x, y) && board.isCellEmpty(x,y) ) 
			{
				boolean result = board.makeMove( currPlayer, x, y );
				
				if( result ) //if move was valid then if opposite player has valid move then switch
				{
						//TODO if board full or no valid move for any user
						//then show the winner and end the game
						if( board.isBoardFull() || 
								(!board.isValidMoveLeft( blackPlayer) && !board.isValidMoveLeft( whitePlayer)) ) 
						{
							board.displayBoard();
							displayGameResults();
							break;
						}
						else { 
							if( currPlayer == whitePlayer && board.isValidMoveLeft( blackPlayer))
								currPlayer = blackPlayer;
							else
								currPlayer = whitePlayer;
						}
				}else 
				{
					System.out.println( "This is invalid move" );
					//check if it was invalid due to player hasing no valid move then switch players
					if( currPlayer == whitePlayer && !board.isValidMoveLeft( whitePlayer))
						currPlayer = blackPlayer;
					else if( currPlayer == blackPlayer && !board.isValidMoveLeft( blackPlayer) )
						currPlayer = whitePlayer;
				}
			}
			else {
				System.out.println( "You entered invalid cell coordinates" );
			}
			
		}
		scanner.close();
	}
	
	private void displayGameResults() {
		System.out.println(" Game finished! ");
		if( board.getWinner() == whitePlayer.getDisk() )
			System.out.println( "Winner is: " + whitePlayer.getName() );
		else if(board.getWinner() == blackPlayer.getDisk() )
			System.out.println( "Winner is: " + blackPlayer.getName() );
		else
			System.out.println(" It's a tie!");
	}
	
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Game game = new Game();
		game.startGame();
	}
}